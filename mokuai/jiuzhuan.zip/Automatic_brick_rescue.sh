#!/system/bin/sh
#特别鸣谢Magisk提供服务支持：by topjohnwu


Disable_All_Modules() {
    ls "/data/adb/modules" | while read i; do
        [[ "$i" = "$MODID" ]] && continue
        touch "/data/adb/modules/$i/disable" &>/dev/null
    done
    Reserve
    reboot
    
}

Statistics() {
    if [[ ! -f $LOG ]]; then
        echo "1" >$LOG
    else
        Number_of_brick_rescue=`cat $LOG`
        p="$(expr $Number_of_brick_rescue + 1)"
        echo "$p" >$LOG
    fi
}

Unfreezing() {

[ -z $BOOTMODE ] && ps | grep zygote | grep -qv grep && BOOTMODE=true
[ -z $BOOTMODE ] && ps -A 2>/dev/null | grep zygote | grep -qv grep && BOOTMODE=true
[ -z $BOOTMODE ] && BOOTMODE=false
rm -rf /data/system/users/0/package-restrictions.xml 
    
exit 0
}

bmd(){
cat  ${0%/*}/白名单.conf | sed '/^[[:space:]]*$/d;/^#/d'
}

function Reserve(){
for i in $(bmd);do 
	rm /data/adb/modules/"$i"/disable &>/dev/null
done
}

MODDIR=${0%/*}
MODID=${MODDIR##*/}
Module_XinXi=$MODDIR/module.prop
START_LOG=$MODDIR/Number_of_starts.log
LOG=$MODDIR/Number_of_brick_rescue.log
VERSION=$MODDIR/now_version
now_version=$(getprop ro.system.build.version.incremental)



if [[ ! -f $START_LOG ]]; then
    echo 0 >"$START_LOG"
    Frequency2=1
else
    Frequency=`cat $START_LOG`
    Frequency2="$(expr $Frequency + 1)"
    echo "$Frequency2" >"$START_LOG"
    echo "$now_version" > "$VERSION"  


fi
    if [[ $Frequency2 -eq 2 ]]; then
        chmod 000 /data/adb/service.d/* /data/adb/post-fs-data.d/*
        Statistics
        Disable_All_Modules
    elif [[ $Frequency2 -ge 4 ]]; then
        rm -f "$START_LOG"
        Statistics
        Unfreezing
        reboot 
    fi

   exit 0
