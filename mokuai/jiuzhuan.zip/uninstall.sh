rm -rf /data/adb/modules/Automatic_brick_rescue


